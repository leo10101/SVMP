package com.traqueasia.SVMP.shared.i18n;

import com.traqueasia.WAF.shared.i18n.I18nKey;

/**
 *
 * @author tmarshall
 */
public enum I18nKeys implements I18nKey {

    
    EventLog("Event Log"),
    EVENTLOGLEVEL("Event Log Level"),
    ViewEvents("View Events"),
    ViewErrors("View Errors"),
    ViewEvents_Desc("View System Events"),
    ViewErrors_Desc("View System Errors");

    private final String defaultValue;
    private String bundle;
    
    public static final String BUNDLE_NAME = "eventMessages";
    
    private I18nKeys(){
        this.defaultValue = name();
        this.bundle = BUNDLE_NAME;
    }

    private I18nKeys(String defaultValue) {
        this(defaultValue, BUNDLE_NAME);
    }

    private I18nKeys(String defaultValue, String bundle) {
        this.defaultValue = defaultValue;
        this.bundle = bundle;
    }

    @Override
    public String defaultValue() {
        return defaultValue;
    }

    /**
     * @return the bundle
     */
    @Override
    public String getModuleName() {
        return bundle;
    }
}
