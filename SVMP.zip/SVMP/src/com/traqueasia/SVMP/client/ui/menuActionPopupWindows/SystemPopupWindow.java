package com.traqueasia.SVMP.client.ui.menuActionPopupWindows;

import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.layout.VStack;
import com.traqueasia.WAF.client.i18n.UIMessages;

/**
 * Class to display a form in a popup Window
 *
 * @author tmarshall
 */
public class SystemPopupWindow {

    private final Window window;

    public SystemPopupWindow() {
        window = new Window();

        window.setAutoSize(true);
        window.setTitle("Edit Customer");
        window.setShowMinimizeButton(false);
        window.setIsModal(true);
        window.setShowModalMask(true);
        window.setAutoCenter(true);

        window.setCanDragReposition(false);
        window.setCanDragResize(false);

        window.centerInPage();



        ListGrid customerList = new ListGrid();
        customerList.setDataSource(DataSource.get("Customer"));
        customerList.setWidth(700);
        customerList.setHeight(150);
        customerList.setAlternateRecordStyles(true);
        customerList.setAutoFetchData(true);
  
        customerList.setCanEdit(true);  
        customerList.setDataPageSize(50);
        customerList.setCanRemoveRecords(true);

        IButton newcustomerButton = new IButton("Add New Customer");
        newcustomerButton.setWidth(120);
        newcustomerButton.addClickHandler((ClickEvent event) -> {
            customerList.startEditingNew();
        });

        IButton saveCustomerButton = new IButton("Save");
        saveCustomerButton.addClickHandler((ClickEvent event) -> {
            customerList.saveAllEdits();
        });
        VLayout customerListLayout = new VLayout(5);

        customerListLayout.addMember(customerList);
        customerListLayout.addMember(newcustomerButton);
        customerListLayout.addMember(saveCustomerButton);

        window.addItem(customerListLayout);

    }



    public void show() {

        window.show();
    }

    public void hide() {

        window.hide();
    }

    public Window getCanvas() {
        return window;
    }

}
