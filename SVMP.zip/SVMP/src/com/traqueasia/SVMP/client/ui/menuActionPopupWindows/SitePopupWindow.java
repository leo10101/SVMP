package com.traqueasia.SVMP.client.ui.menuActionPopupWindows;

import com.smartgwt.client.data.Criteria;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.layout.VStack;
import com.smartgwt.client.widgets.menu.events.MenuItemClickEvent;
import com.smartgwt.client.widgets.tree.events.NodeContextClickEvent;
import com.traqueasia.SVMP.server.DAO.SiteDAOService;
import com.traqueasia.SVMP.server.entities.Site;
import com.traqueasia.WAF.client.i18n.UIMessages;
import java.util.List;

/**
 * Class to display a form in a popup Window
 *
 * @author tmarshall
 */
public class SitePopupWindow {

    private final Window window;
    //private SiteDAOService siteDAO;
    private final ListGrid siteList;

    public SitePopupWindow(String id) {
        window = new Window();

        window.setAutoSize(true);
        window.setTitle("Edit Customer");
        window.setShowMinimizeButton(false);
        window.setIsModal(true);
        window.setShowModalMask(true);
        window.setAutoCenter(true);

        window.setCanDragReposition(false);
        window.setCanDragResize(false);

        window.centerInPage();

        siteList = new ListGrid();
        siteList.setDataSource(DataSource.get("TreeGrid"));
        siteList.setWidth(700);
        siteList.setHeight(150);
        siteList.setAlternateRecordStyles(true);
        siteList.setAutoFetchData(true);

        siteList.setCanEdit(true);
        siteList.setDataPageSize(50);
        siteList.setCanRemoveRecords(true);
        
//        Criteria c = new Criteria();
//        
//        c.addCriteria("parentId", id);
//        siteList.setCriteria(c);

//        List<Site> allSites = siteDAO.getSites();
//
//        String customer = event.getNode().getAttribute("id");
//        List<Site> childSites = null;
//
//        for (Site s : allSites) {
//            if (("customer_" + s.getCustomer().getCustomerId().toString()) == customer) {
//                childSites.add(s);
//            }
//        }
//        
//        RecordList recordList = new RecordList();
//        for (Site s : childSites)
//        {
//            Record record = new Record();
//            record.setAttribute("name", s.getSiteName());
//          
//            recordList.add(record);
//        }
//        
//        siteList.setData(recordList);
//        
        IButton newcustomerButton = new IButton("Add New Site");
        newcustomerButton.setWidth(120);
        newcustomerButton.addClickHandler((ClickEvent event1) -> {
            siteList.startEditingNew();
        });

        IButton saveCustomerButton = new IButton("Save");
        saveCustomerButton.addClickHandler((ClickEvent event2) -> {
            siteList.saveAllEdits();
        });
        VLayout siteListLayout = new VLayout(5);

        siteListLayout.addMember(siteList);
        siteListLayout.addMember(newcustomerButton);
        siteListLayout.addMember(saveCustomerButton);

        window.addItem(siteListLayout);

    }

    public void show() {

        window.show();
    }

    public void hide() {

        window.hide();
    }

    public Window getCanvas() {
        return window;
    }

    public void setSiteToEdit(String id) {
        Criteria c = new Criteria();
        //id = id.replace("customer_", "");
        c.addCriteria("parentId", id);
        siteList.setCriteria(c);
    }

}
