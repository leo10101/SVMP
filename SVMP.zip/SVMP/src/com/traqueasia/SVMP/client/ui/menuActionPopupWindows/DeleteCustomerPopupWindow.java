//package com.traqueasia.SVMP.client.ui.menuActionPopupWindows;
//
//import com.smartgwt.client.data.Criteria;
//import com.smartgwt.client.data.DataSource;
//import com.smartgwt.client.types.Alignment;
//import com.smartgwt.client.util.BooleanCallback;
//import com.smartgwt.client.util.SC;
//import com.smartgwt.client.widgets.IButton;
//import com.smartgwt.client.widgets.Label;
//import com.smartgwt.client.widgets.Window;
//import com.smartgwt.client.widgets.events.ClickEvent;
//import com.smartgwt.client.widgets.events.ClickHandler;
//import com.smartgwt.client.widgets.form.DynamicForm;
//import com.smartgwt.client.widgets.grid.ListGrid;
//import com.smartgwt.client.widgets.layout.HLayout;
//import com.smartgwt.client.widgets.layout.VLayout;
//import com.smartgwt.client.widgets.layout.VStack;
//import com.traqueasia.WAF.client.i18n.UIMessages;
//
///**
// * Class to display a form in a popup Window
// *
// * @author tmarshall
// */
//public class DeleteCustomerPopupWindow {
//
//    private final Window window;
//    ListGrid customerList = new ListGrid();
//
//    public DeleteCustomerPopupWindow(String id) {
//        window = new Window();
//
//       
//        window.setWidth(700);
//        window.setHeight(150);
//        window.setTitle("Delete Customer");
//        window.setShowMinimizeButton(false);
//        window.setIsModal(true);
//        window.setShowModalMask(true);
//        window.setAutoCenter(true);
//        window.setCanDragReposition(false);
//        window.setCanDragResize(false);
//        window.centerInPage();
//       
////        customerList.setDataSource(DataSource.get("Customer"));
////        id = id.replace("customer_", "");
////        int intId= Integer.parseInt(id);	
////        setCustomerToEdit(id);
////       
////        IButton deleteButton = new IButton("Delete");
////        deleteButton.setWidth(120);
////        deleteButton.addClickHandler((ClickEvent event) -> {
////            customerList.deselectRecord(intId);
////        });
////
////        IButton cancelButton = new IButton("Cancel");
////        cancelButton.addClickHandler((ClickEvent event) -> {
////            window.close();
////        });
////        VLayout customerListLayout = new VLayout(5);
////
////        customerListLayout.addMember(customerList);
////        HLayout buttonsLayout=new HLayout();
////        buttonsLayout.addMember(deleteButton);
////        buttonsLayout.addMember(cancelButton);
////        customerListLayout.addMember(buttonsLayout);
//        
//        window.addItem(customerListLayout);
//
//    }
//
//
//
//    public void show() {
//
//        window.show();
//    }
//
//    public void hide() {
//
//        window.hide();
//    }
//
//    public Window getCanvas() {
//        return window;
//    }
//
//
//    public void setCustomerToEdit(String id) {
//        Criteria c = new Criteria();
//        //id = id.replace("customer_", "");
//        c.addCriteria("customerId", id);
//        customerList.setCriteria(c);
//    }
//}