/*
 * Copyright 2018 TRAQuE Pte Ltd 				
 * -----------------------------------------------------------------------
 *
 * TRAQuE Pte Ltd
 * Standard Software End-User License Agreement
 * NOTE: THIS IS A LEGAL AGREEMENT BETWEEN TRAQuE PTE LTD ("TRAQuE") AND YOU (EITHER AN INDIVIDUAL OR SINGLE ENTITY) FOR THE SOFTWARE PRODUCTS WHICH FOLLOW (COLLECTIVELY THE "SOFTWARE PRODUCT"). PLEASE READ THIS DOCUMENT and any provided supplemental license terms (COLLECTIVELY THE "AGREEMENT") CAREFULLY. IF YOU DO NOT DO NOT AGREE, CLICK DISAGREE.
 * BY OPENING THE SOFTWARE MEDIA PACKAGE, INCLUDING DOWNLOADABLE CONTENT, YOU AGREE TO THE TERMS OF THIS AGREEMENT. IF YOU ARE ACCESSING THE SOFTWARE ELECTRONICALLY, INDICATE YOUR ACCEPTANCE OF THESE TERMS BY SELECTING THE "AGREE" BUTTON AT THE END OF THIS AGREEMENT. IF YOU DO NOT AGREE TO ALL OF THESE TERMS, PROMPTLY RETURN THE UNUSED SOFTWARE TO YOUR PLACE OF PURCHASE FOR A REFUND OR, IF THE SOFTWARE IS ACCESSED ELECTRONICALLY, SELECT THE "DISAGREE" BUTTON AT THE END OF THIS AGREEMENT.
 * 1. GRANT OF LICENSE. This Agreement grants you the following rights: You may install, use, access, display, run or otherwise interact with ("RUN") one copy of the SOFTWARE PRODUCT, on a single computer, workstation, server, terminal or other digital electronic device ("COMPUTER"). All rights not expressly granted are reserved by TRAQuE.
 * 2. RESTRICTIONS. Title to the SOFTWARE PRODUCT and all associated intellectual property rights are retained by TRAQuE and/or its licensors. You may not resell, or otherwise transfer for value, the SOFTWARE PRODUCT. You may not reverse engineer, decompile, or disassemble the SOFTWARE PRODUCT, except and only to the extent that such activity is expressly permitted by applicable law notwithstanding this limitation.
 * 3. SEPARATION OF COMPONENTS. The SOFTWARE PRODUCT is licensed as a single product. Its component parts may not be separated for use on more than one COMPUTER, other than in its intended use as a web application where the server provides content via a single web server for the user to interact with remotely.
 * 4. COPYRIGHTS AND TRADEMARKS. This AGREEMENT does not grant you any rights in connection with any copyrights or trademarks of TRAQuE. All title and copyrights in and to the accompanying printed or electronically supplied materials and or documentation is owned by TRAQuE. This AGREEMENT grants you no rights to use such content. You may not copy the printed materials accompanying the SOFTWARE PRODUCT.
 * 5. RENTAL. You may not rent, lease, or lend the SOFTWARE PRODUCT, unless you have purchased a rental license for such use.
 * 6. LIMITED WARRANTY. The SOFTWARE PRODUCT IS PROVIDED "AS IS". TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, TRAQuE AND ITS SUPPLIERS DISCLAIM ALL OTHER WARRANTIES AND CONDITIONS, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT, WITH REGARD TO THE SOFTWARE PRODUCT, AND THE PROVISION OF OR FAILURE TO PROVIDE SUPPORT SERVICES OR BUG FIXES. THIS LIMITED WARRANTY GIVES YOU SPECIFIC LEGAL RIGHTS, YOU MAY HAVE OTHERS, WHICH VARY FROM STATE/JURISDICTION TO STATE/JURISDICTION. Your exclusive remedy and TRAQuE's entire liability under this limited warranty will be at TRAQuE's option to replace the SOFTWARE PRODUCT or refund the fee paid for the SOFTWARE PRODUCT.
 * 7. LIMITATION OF LIABILITY. TO THE EXTENT NOT PROHIBITED BY LAW, IN NO EVENT WILL TRAQuE OR ITS LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR ANY SPECIAL, INDIRECT, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF OR RELATED TO THE USE OF OR INABILITY TO USE THE SOFTWARE PRODUCT, EVEN IF TRAQuE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. In no event will TRAQuE's liability to you, whether in contract, tort (including negligence), or otherwise, exceed the amount paid by you for the SOFTWARE PRODUCT under this agreement. The foregoing limitations will apply even if the above stated warranty fails of its essential purpose.
 * 8. TERMINATION. This AGREEMENT is effective until terminated. You may terminate this AGREEMENT at any time by destroying all copies of the SOFTWARE PRODUCT. This AGREEMENT will terminate immediately without notice from TRAQuE if you fail to comply with any provision of this AGREEMENT. Upon Termination, you must destroy all copies of the SOFTWARE PRODUCT.
 * 9. EXPORT REGULATIONS. The SOFTWARE PRODUCT and all technical data delivered under this AGREEMENT are subject to Singapore export control laws and may be subject to export or import regulations in other countries. You agree to comply strictly with all such laws and regulations and acknowledge that you have the responsibility to obtain such licenses to export, re-export, or import as may be required after delivery to you.
 * 10. U.S. Government Restricted Rights. If the SOFTWARE PRODUCT is being acquired by or on behalf or the U.S. Government or by a U.S. Government prime contractor or subcontractor (at any tier), then the Government's rights in the SOFTWARE PRODUCT and accompanying documentation will be only as set forth in this AGREEMENT; this is in accordance with 48 CFR 227.7201 through 227.7202-4 (for Department of Defence (DOD) acquisitions) and with 48 CFR 2.101 and 12.212 (for non-DOD acquisitions).
 * 11. MISCELLANEOUS. This AGREEMENT is the entire agreement between you and TRAQuE relating to the subject matter. It supersedes all prior or contemporaneous oral or written communications, proposals, presentations and warranties and prevails over any conflicting or additional terms of any quote, order, acknowledgment, or other communication between the parties relating to its subject matter during the term of this AGREEMENT. No modification of this AGREEMENT will be binding, unless in writing and signed by an authorised representative of each party. If you are acquiring this SOFTWARE PRODUCT in Singapore, this AGREEMENT is governed by the laws of Singapore. If this SOFTWARE PRODUCT was acquired outside the Singapore, then local law may apply. Should you have any questions concerning this AGREEMENT, please contact, TRAQuE's Pte Ltd, Contracts Administration, 51 Bukit Batok Crescent, 08-25, Singapore 658077.
 */
package com.traqueasia.SVMP.client.i18n;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.Messages;
import com.google.gwt.i18n.client.Messages.DefaultMessage;

/**
 *
 * @author tmarshall
 */
public interface SVMPUIMessages extends Messages {

    public static final SVMPUIMessages LANG = GWT.create(SVMPUIMessages.class);

   @DefaultMessage("SVMP")
    String SVMP();
    
    @DefaultMessage("view")
    String view();
    
    @DefaultMessage("Add system")
    String systemAdd();
    
    @DefaultMessage("Add site")
    String siteAdd();
    
    @DefaultMessage("Add customer")
    String customerAdd();

    @DefaultMessage("Edit system")
    String systemEdit();  
    
    @DefaultMessage("Edit site")
    String siteEdit(); 
    
    @DefaultMessage("Edit customer")
    String customerEdit(); 
    
    @DefaultMessage("Delete system")
    String systemDelete(); 
    
    @DefaultMessage("Delete site")
    String siteDelete(); 
    
    @DefaultMessage("Delete customer")
    String customerDelete(); 
}
