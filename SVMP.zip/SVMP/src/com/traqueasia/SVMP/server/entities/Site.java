package com.traqueasia.SVMP.server.entities;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity // This tells Hibernate to make a table out of this class
public class Site{
    @Id
    @Column (nullable = false)  
    @GeneratedValue (strategy = GenerationType.IDENTITY)  
    private Integer siteId;
    
    private String siteName;
    
    
    @ManyToOne
    @JoinColumn(name = "customerId")
    private Customer customer;
    
    @OneToMany(cascade={CascadeType.ALL}, orphanRemoval=true)  
    @JoinColumn(name="siteId", referencedColumnName="siteId")  
    private List<Systems> systems; 

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
  
    

    
    public Site ()  
    {  
    }  

    public Integer getSiteId() {
        return siteId;
    }

    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }



    public List<Systems> getSystems() {
        return systems;
    }

    public void setSystems(List<Systems> systems) {
        this.systems = systems;
    }


    
}