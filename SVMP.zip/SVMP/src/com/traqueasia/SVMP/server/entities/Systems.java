package com.traqueasia.SVMP.server.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



@Entity // This tells Hibernate to make a table out of this class
public class Systems {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer systemId;
       
    private String systemName;

    private String category;
    
    private Boolean GMP;
    
//    @ManyToOne
//    @JoinColumn(name = "siteId")
//    private Site site;

 

    public Integer getSystemId() {
        return systemId;
    }

    public void setSystemId(Integer systemId) {
        this.systemId = systemId;
    }

    public String getSystemName() {
        return systemName;
    }

    public void setSystemName(String systemName) {
        this.systemName = systemName;
    }





	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Boolean getGMP() {
		return GMP;
	}

	public void setGMP(Boolean gMP) {
		GMP = gMP;
	}

//	public Site getSite() {
//		return site;
//	}
//
//	public void setSite(Site site) {
//		this.site = site;
//	}
//	


}