package com.traqueasia.svmp.entities;

import java.util.Collections;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity // This tells Hibernate to make a table out of this class
public class Site{
    @Id
    private String name;
    
//    @ManyToOne
//    @JoinColumn
//    private Customer customer;
    
    @OneToMany
    private Set<System> systems;


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public Customer getCustomer() {
//		return customer;
//	}
//
//	public void setCustomer(Customer customer) {
//		this.customer = customer;
//	}

	public Set<System> getSystems() {
		return systems;
	}


	public void addSystem(System newSystem) {
		Set<System> system=Collections.emptySet();  ;
		if(this.getSystems()==null)
			system.add(newSystem);
		else {
			system=this.getSystems();
			system.add(newSystem);
		};
		this.systems = system;
	}

}