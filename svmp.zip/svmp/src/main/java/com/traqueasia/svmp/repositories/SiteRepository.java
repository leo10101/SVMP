package com.traqueasia.svmp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.traqueasia.svmp.entities.Site;


public interface SiteRepository extends CrudRepository<Site, String> {
	//Site findBySiteName(@Param("name")String name);
}
