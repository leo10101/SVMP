package com.traqueasia.svmp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SvmpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SvmpApplication.class, args);
	}

}
