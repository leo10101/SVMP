package com.traqueasia.svmp.entities;

import java.util.Collections;
import java.util.Set;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity // This tells Hibernate to make a table out of this class
public class Customer  {
    @Id
    private Integer id;
    
    private String name;

    @OneToMany
    private Set<Site> sites;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Site> getSites() {
		return sites;
	}


	public void addSite(Site newSite) {
		Set<Site> site=Collections.emptySet();  ;
		if(this.getSites()==null)
			site.add(newSite);
		else {
			site=this.getSites();
			site.add(newSite);
		};
		this.sites = site;
	}

}