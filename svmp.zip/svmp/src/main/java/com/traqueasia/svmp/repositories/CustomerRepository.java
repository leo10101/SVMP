package com.traqueasia.svmp.repositories;

import org.springframework.data.repository.CrudRepository;
import com.traqueasia.svmp.entities.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Integer> {

}
