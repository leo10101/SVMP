package com.traqueasia.svmp;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.traqueasia.svmp.entities.*;
import com.traqueasia.svmp.entities.System;
import com.traqueasia.svmp.repositories.*;

@Controller    // This means that this class is a Controller
@RequestMapping(path="/svmp") 
public class MainController {
	@Autowired 
	private TaskRepository TaskRepository;
	@Autowired
	private CustomerRepository CustomerRepository;
	@Autowired
	private SiteRepository SiteRepository;
	@Autowired
	private SystemRepository SystemRepository;

	@PostMapping(path="/task/add") // Map ONLY POST Requests
	public @ResponseBody String addNewTask (@RequestParam String name
			, @RequestParam int period) {
		// @ResponseBody means the returned String is the response, not a view name
		// @RequestParam means it is a parameter from the GET or POST request

		Task n = new Task();
		n.setName(name);
		n.setPeriod(period);
		TaskRepository.save(n);
		return "Saved";
	}

	@GetMapping(path="/task/all")
	public @ResponseBody Iterable<Task> getAllTasks() {
		// This returns a JSON or XML with the users
		return TaskRepository.findAll();
	}
	
	@PostMapping(path="/customer/add") // Map ONLY POST Requests
	public @ResponseBody String addNewCustomer (@RequestParam Integer id,@RequestParam String name) {
		// @ResponseBody means the returned String is the response, not a view name
		// @RequestParam means it is a parameter from the GET or POST request

		Customer c = new Customer();
		c.setId(id);
		c.setName(name);
		CustomerRepository.save(c);
		return "Saved";
	}
	
	@PostMapping(path="/customer/assign") // Map ONLY POST Requests
	public @ResponseBody String assignNewCustomer (@RequestParam Integer id,@RequestParam String name) {
		// @ResponseBody means the returned String is the response, not a view name
		// @RequestParam means it is a parameter from the GET or POST request

		Optional<Customer> customerO=CustomerRepository.findById(id);
		Optional<Site> siteO=SiteRepository.findById(name);
		
		Customer customer=customerO.get();
		Site site=siteO.get();

		customer.addSite(site);
		SiteRepository.save(site);
        
		return "Saved";
	}

	@GetMapping(path="/customer/all")
	public @ResponseBody Iterable<Customer> getAllCustomers() {
		// This returns a JSON or XML with the users
		return CustomerRepository.findAll();
	}
	
	@PostMapping(path="/site/add") // Map ONLY POST Requests
	public @ResponseBody String addNewSite (@RequestParam String name) {
		// @ResponseBody means the returned String is the response, not a view name
		// @RequestParam means it is a parameter from the GET or POST request

		Site s = new Site();
		s.setName(name);
		SiteRepository.save(s);
		return "Saved";
	}
	
	@PostMapping(path="/site/assign") // Map ONLY POST Requests
	public @ResponseBody String assignNewSite (@RequestParam String name
			, @RequestParam Integer id) {
		// @ResponseBody means the returned String is the response, not a view name
		// @RequestParam means it is a parameter from the GET or POST request
		Optional<Site> siteO=SiteRepository.findById(name);
		Optional<System> systemO=SystemRepository.findById(id);
		
		Site site=siteO.get();
		System system=systemO.get();
//		system.setSite(site);
//		SystemRepository.save(system);
		site.addSystem(system);
		SiteRepository.save(site);
        
		return "Saved";
	}

	@GetMapping(path="/site/all")
	public @ResponseBody Iterable<Site> getAllSites() {
		// This returns a JSON or XML with the users
		return SiteRepository.findAll();
	}
	
	@PostMapping(path="/system/add") // Map ONLY POST Requests
	public @ResponseBody String addNewSystem (@RequestParam String name
			, @RequestParam String category,@RequestParam Boolean gMP) {
		// @ResponseBody means the returned String is the response, not a view name
		// @RequestParam means it is a parameter from the GET or POST request

		System s = new System();
		s.setName(name);
		s.setCategory(category);
		s.setGMP(gMP);
		SystemRepository.save(s);
		return "Saved";
	}

	@GetMapping(path="/system/all")
	public @ResponseBody Iterable<System> getAllSystems() {
		// This returns a JSON or XML with the users
		return SystemRepository.findAll();
	}
}