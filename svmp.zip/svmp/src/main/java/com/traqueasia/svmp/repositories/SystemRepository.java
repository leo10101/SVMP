package com.traqueasia.svmp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.traqueasia.svmp.entities.System;

public interface SystemRepository extends CrudRepository<System, Integer> {

}